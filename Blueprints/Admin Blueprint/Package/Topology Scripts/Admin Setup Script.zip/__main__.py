
import admin_setup_script

admin_setup_script.execute()
